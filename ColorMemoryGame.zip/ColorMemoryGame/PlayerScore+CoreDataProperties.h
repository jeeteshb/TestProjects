//
//  PlayerScore+CoreDataProperties.h
//  ColorMemoryGame
//
//  Created by jeetesh bhoria on 03/06/17.
//  Copyright © 2017 jeetesh bhoria. All rights reserved.
//

#import "PlayerScore+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface PlayerScore (CoreDataProperties)

+ (NSFetchRequest<PlayerScore *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *name;
@property (nonatomic) int64_t score;

@end

NS_ASSUME_NONNULL_END

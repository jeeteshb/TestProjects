//
//  AppDelegate.h
//  ColorMemoryGame
//
//  Created by jeetesh bhoria on 28/05/17.
//  Copyright © 2017 jeetesh bhoria. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong) NSPersistentContainer *persistentContainer;
 

+ (AppDelegate *)getInstance;
- (void)saveContext;


@end


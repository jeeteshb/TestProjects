//
//  main.m
//  ColorMemoryGame
//
//  Created by jeetesh bhoria on 28/05/17.
//  Copyright © 2017 jeetesh bhoria. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

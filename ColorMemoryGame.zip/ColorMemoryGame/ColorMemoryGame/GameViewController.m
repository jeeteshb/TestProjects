//
//  GameViewController.m
//  ColorMemoryGame
//
//  Created by jeetesh bhoria on 28/05/17.
//  Copyright © 2017 jeetesh bhoria. All rights reserved.
//

#import "GameViewController.h"
#import "HighScoreViewController.h"
#import "PlayerScore+CoreDataClass.h"
#import "AppDelegate.h"

@interface GameViewController ()
@property (weak, nonatomic) IBOutlet UIView *dimView;
@property (weak, nonatomic) IBOutlet UIView *playerNameView;
@property (weak, nonatomic) IBOutlet UITextField *playerName;

@end

@implementation GameViewController



NSMutableArray<Card*> *colorCards;
NSMutableArray *repeated;
NSMutableString *currentScore;
NSString *cardName1;
NSString *cardName2;

UIButton *button1;
UIButton *button2;

PlayerScore * dbplayerScore;

int chance = 0;
int totalCards = 8;
int numberOfCards = 16;
int randd = 0;
int score = 0;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [_dimView setHidden:YES];
    colorCards = [[NSMutableArray alloc] initWithCapacity:16];
    repeated   = [[NSMutableArray alloc] initWithCapacity:16];
    currentScore = [[NSMutableString alloc] init];
    
    [self initializeCards];
    [self ShuffleArray];
    
    _scorelabel.text = @"Score: 0";
}

- (void) viewWillAppear:(BOOL)animated{
    score = 0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma Game play methods

/* Card click method
 **/
- (IBAction)CardClicked:(id)sender {
    
    chance = chance + 1;
    
    if(chance == 1){
        
        NSInteger numtag = [sender tag];
        cardName1 = colorCards[numtag-1].cardName;
        UIImage *image = colorCards[numtag-1].imageColor;
        [sender setBackgroundImage:image  forState:UIControlStateNormal];
        button1 = sender;
    }
    else if(chance == 2){
    
        NSInteger numtag = [sender tag];
        cardName2 = colorCards[numtag-1].cardName;
        UIImage *image = colorCards[numtag-1].imageColor;
        [sender setBackgroundImage:image  forState:UIControlStateNormal];
        button2 = sender;
        chance = 0;

    
        if([cardName1 isEqualToString:cardName2]){
            score = score + 2;
            _scorelabel.text = [NSString stringWithFormat:@"Score: %d", score];
            
            [self performSelector:@selector(removeButton:) withObject:button1 afterDelay:1.0f];
            [self performSelector:@selector(removeButton:) withObject:button2 afterDelay:1.0f];
            
            numberOfCards = numberOfCards -2;
            if(numberOfCards == 0)
            {
                numberOfCards = 16;
                [_dimView setHidden:NO];
                CGFloat x1 = [UIScreen mainScreen].bounds.size.width/2;
                CGFloat y1 = [UIScreen mainScreen].bounds.size.height/2;
                CGPoint posicion = CGPointMake(x1, y1);
                
                [UIView animateWithDuration:0.5 delay:0 options:0 animations:^{
                    _playerNameView.center = posicion;
                } completion:^(BOOL finished) {
                    
                }];
            }
        }
        else {
            score = score -1;
            _scorelabel.text = [NSString stringWithFormat:@"Score: %d", score];
            
            [self performSelector:@selector(resetButtons:) withObject:button1 afterDelay:1.0f];
            [self performSelector:@selector(resetButtons:) withObject:button2 afterDelay:1.0f];
        }
    }
    
}

-(void) ShuffleArray {
    for (int i = 0; i < colorCards.count; i++) {
        int randomInt1 = arc4random() % [colorCards count];
        int randomInt2 = arc4random() % [colorCards count];
        [colorCards exchangeObjectAtIndex:randomInt1 withObjectAtIndex:randomInt2];
    }
}

/*Check if random number repeating
 **/
- (bool) isRepeated: (int) randd{
    
    for(int i=0; i<[repeated count];i++){
        if(randd == [[repeated objectAtIndex:i] integerValue]){
            return true;
        }
    }
    [repeated addObject:[NSNumber numberWithInt:randd]];
    return false;
}


/*Getting Random number
 **/
- (int) getRandNumber{
    int random = 0;
    do {
        random = arc4random() % totalCards;
    }while ([self isRepeated:random]);
    if(random == 0){
        random = 8;
    }
    
    return random;
}

/*This method initializes the cards with image color
 **/
- (void) initializeCards{
    
    for(int i=1; i<=8; i++){
        
        int num = [self getRandNumber];
         Card * c1 = [[Card alloc] init];
         Card * c2 = [[Card alloc] init];
        NSString *strNum = [NSString stringWithFormat:@"%@%d",@"colour", num];
         [c1 setImageColor: [UIImage imageNamed: strNum]];
         [c1 setCardName:[NSString stringWithFormat:@"colour%d",num]];
         [c1 setButtonNumber: num];
         [c2 setImageColor: [UIImage imageNamed: strNum]];
         [c2 setCardName:[NSString stringWithFormat:@"colour%d",num]];
         [c2 setButtonNumber: num];
         [colorCards addObject:c1];
         [colorCards addObject:c2];
        NSLog(@"Random Number: %i", num);
    }
}

/*This method resets the card with default image.
 **/
- (void) resetButtons: (UIButton*) button {
    
    dispatch_async(dispatch_get_main_queue(),^{
        [button setBackgroundImage:[UIImage imageNamed:@"card_bg"] forState:UIControlStateNormal];
    });
    
}

/*This method removes the card once matched
 **/
-(void) removeButton: (UIButton*) button {

    button.alpha = 0;
}
- (IBAction)HighScorebtnClicked:(id)sender {
    
    if([_playerName.text  isEqual: @""] || _playerName.text == nil) {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning..."
                                                        message:@"Player Name can't be empty."
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
    
    }
    else {
        [self saveToCoreData];
        
        UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        HighScoreViewController * highScoreVC = (HighScoreViewController*)[sb instantiateViewControllerWithIdentifier: @"HighScoreViewController"];
        [self.navigationController pushViewController:highScoreVC animated:YES];
    }
}


#pragma Core Data

/*get the core data context and save the score in it.
 **/
-(void) saveToCoreData {
    
//    [self removePlayerScore];
    NSError *error = nil;
    NSManagedObjectContext *manageObjectContext = ((AppDelegate*)[[UIApplication sharedApplication] delegate]).persistentContainer.viewContext;
    dbplayerScore = [NSEntityDescription insertNewObjectForEntityForName:@"PlayerScore"
                                                                      inManagedObjectContext:manageObjectContext];
    [dbplayerScore setValue:_playerName.text forKey:@"name"];
    [dbplayerScore setValue:[NSNumber numberWithInteger:score] forKey:@"score"];
    [manageObjectContext save:&error];
}

/*Remove the core data entity from core data.
 **/
- (void) removePlayerScore {
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSManagedObjectContext *managedObjectContext = ((AppDelegate*)[[UIApplication sharedApplication] delegate]).persistentContainer.viewContext;
    fetchRequest.entity =
    [NSEntityDescription entityForName:@"PlayerScore"
                inManagedObjectContext:managedObjectContext];
    
    NSArray *results =
    [managedObjectContext executeFetchRequest:fetchRequest error:nil];
    
    for (PlayerScore *Entity in results) {
        [managedObjectContext deleteObject:Entity];
    }
}
@end

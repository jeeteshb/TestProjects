//
//  HighScoreViewController.h
//  ColorMemoryGame
//
//  Created by jeetesh bhoria on 03/06/17.
//  Copyright © 2017 jeetesh bhoria. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HighScoreViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>

@end

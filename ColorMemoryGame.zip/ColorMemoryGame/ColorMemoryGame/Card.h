//
//  Card.h
//  ColorMemoryGame
//
//  Created by jeetesh bhoria on 02/06/17.
//  Copyright © 2017 jeetesh bhoria. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Card : NSObject{
}

@property (nonatomic) NSString *cardName;
@property (nonatomic) int buttonNumber;
@property (nonatomic) UIImage* imageColor;


@end

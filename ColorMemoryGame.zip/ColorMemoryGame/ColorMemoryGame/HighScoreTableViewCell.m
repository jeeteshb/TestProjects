//
//  HighScoreTableViewCell.m
//  ColorMemoryGame
//
//  Created by jeetesh bhoria on 03/06/17.
//  Copyright © 2017 jeetesh bhoria. All rights reserved.
//

#import "HighScoreTableViewCell.h"

@implementation HighScoreTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

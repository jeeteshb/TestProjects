//
//  HighScoreViewController.m
//  ColorMemoryGame
//
//  Created by jeetesh bhoria on 03/06/17.
//  Copyright © 2017 jeetesh bhoria. All rights reserved.
//

#import "HighScoreViewController.h"
#import "ViewController.h"
#import "HighScoreTableViewCell.h"
#import "AppDelegate.h"
#import "PlayerScore+CoreDataClass.h"


@interface HighScoreViewController()

@end

@implementation HighScoreViewController
NSUInteger dbcount;
NSMutableArray<PlayerScore*> *playerSortedArray;

- (void)viewDidLoad {
    
    NSError *errorFetch = nil;
    NSManagedObjectContext *managedObjectContext = ((AppDelegate*)[[UIApplication sharedApplication] delegate]).persistentContainer.viewContext;;
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    request.entity = [NSEntityDescription entityForName:@"PlayerScore" inManagedObjectContext:managedObjectContext];
    
    NSSortDescriptor *sortField = [[NSSortDescriptor alloc] initWithKey:@"score" ascending:NO];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortField, nil];
    [request setSortDescriptors:sortDescriptors];
    playerSortedArray = [[managedObjectContext executeFetchRequest:request error:&errorFetch] mutableCopy];
    NSError *error = nil;
    dbcount = [managedObjectContext countForFetchRequest:request
                                                            error:&error];
}

/*Go to the root view controller
 **/
- (IBAction)GoToStart:(id)sender {
    
    ViewController *root = (ViewController*)[self.navigationController.viewControllers objectAtIndex:0] ;
    [self.navigationController popToViewController:root animated:YES ];

}

#pragma TableView Delegate

/*UITableView Delegate method
 **/
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

/*UITableView Delegate method
 **/
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return dbcount;
}

/*UITableView Delegate method
 **/
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    HighScoreTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HighScoreTableViewCell"];
    
    if(cell == nil)
        cell = [[HighScoreTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([HighScoreTableViewCell class])];
    
    cell.rank.text = [NSString stringWithFormat:@"%ld", (long)indexPath.row + 1];
    cell.name.text = playerSortedArray[indexPath.row].name;
    cell.score.text = [NSString stringWithFormat:@"%ld", (long)playerSortedArray[indexPath.row].score];
    
    return cell;
}

@end

//
//  GameViewController.h
//  ColorMemoryGame
//
//  Created by jeetesh bhoria on 28/05/17.
//  Copyright © 2017 jeetesh bhoria. All rights reserved.
//

#import "ViewController.h"
#import "Card.h"

@interface GameViewController : UIViewController<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIButton *card1;
@property (weak, nonatomic) IBOutlet UIButton *card2;
@property (weak, nonatomic) IBOutlet UIButton *card3;
@property (weak, nonatomic) IBOutlet UIButton *card4;
@property (weak, nonatomic) IBOutlet UIButton *card5;
@property (weak, nonatomic) IBOutlet UIButton *card6;
@property (weak, nonatomic) IBOutlet UIButton *card7;
@property (weak, nonatomic) IBOutlet UIButton *card8;
@property (weak, nonatomic) IBOutlet UIButton *card9;
@property (weak, nonatomic) IBOutlet UIButton *card10;
@property (weak, nonatomic) IBOutlet UIButton *card11;
@property (weak, nonatomic) IBOutlet UIButton *card12;
@property (weak, nonatomic) IBOutlet UIButton *card13;
@property (weak, nonatomic) IBOutlet UIButton *card14;
@property (weak, nonatomic) IBOutlet UIButton *card15;
@property (weak, nonatomic) IBOutlet UIButton *card16;


@property (weak, nonatomic) IBOutlet UILabel *scorelabel;

- (IBAction)CardClicked:(id)sender;
- (bool) isRepeated: (int) randd;


@end

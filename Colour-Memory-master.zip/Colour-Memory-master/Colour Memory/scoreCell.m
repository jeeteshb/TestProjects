//
//  scoreCell.m
//  Colour Memory
//
//  Created by Hector Carrasco on 17-12-13.
//  Copyright (c) 2013 Hector Carrasco. All rights reserved.
//

#import "scoreCell.h"

@implementation scoreCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

@end
